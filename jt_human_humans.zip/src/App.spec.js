describe('a component', function () {
  it('contains true', function () {
    expect(true).toBe(true);
  })
})