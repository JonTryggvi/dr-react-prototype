// import React, { Component } from 'react';
// import Nouislider from 'react-nouislider';
// import './slider.css';

// class Slider extends Component {
//   render() {
//     return (
//       <Nouislider
//         range={{min: 0, max: 200}}
//         start={[0, 100]}
//         tooltips
//       />
//     )
//   }
// }

// export default Slider;

